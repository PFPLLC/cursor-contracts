<!-- OVERRIDE: Serverless Function -->
📌 Use case: Vercel/Netlify/AWS Lambda function
✅ Enforce: Statelessness, async handling, input validation, consistent HTTP codes
⚠️ Violation: Blocking or stateful logic
> ⚠️ Serverless contract breach. Refactoring to stateless async handler.
