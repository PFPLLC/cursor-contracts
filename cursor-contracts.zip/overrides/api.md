<!-- OVERRIDE: API-Only Backend -->
📌 Use case: Node/Express API
✅ Enforce: Input validation, consistent error middleware, OpenAPI docs
⚠️ Violation: No schema validation or inconsistent error response
> ⚠️ API compliance failure. Applying standardized response handling.
