<!-- OVERRIDE: UI/Frontend Project -->
📌 Use case: React, Tailwind, modern frontend
✅ Enforce: Semantic HTML, responsive layout, ARIA compliance
⚠️ Violation: Unstructured markup, inaccessible components
> ⚠️ UI hygiene violation. Refactoring structure now.
