<!-- OVERRIDE: Analytics & Privacy Compliance -->
📌 Use case: Projects with user tracking
✅ Enforce: Consent gating, do-not-track support, anonymized data, documented collection
⚠️ Violation: Premature tracking or leaked PII
> ⚠️ Privacy compliance failure. Removing analytics until opt-in is implemented.
